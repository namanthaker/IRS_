 ## Libraries imported 
 -> pyttsx3
 -> datetime
 -> speechRecognizer
 -> wikipedia
 -> webbrowser
 -> os
 -> pyatogui
 -> psutil
 -> pyjokes
 -> smtplib
 -> socket
 -> pyaudio

 ## Steps to Run the script 

 1. Install all libraries through pip
 2. run the code by : python main.py
 3. After initiall startup of script audio, give various voice commands like:
    - "Take screenshot"
    - " Search iron man on wikipedia"
    - " What is the time " 
    - "Tell me the joke"
    - "What is todays date"
    - Text to speech
    - CPU usage
    - show battery percentage
    - Restart pc
    - Shutdown PC
    - Logout User
    - remember that _____
    - Search _____ in chrome
    - Search _____ in wikipedia  
 4. All commands will be executed as per the definition.
 5. To exit the code give command "bye" or "go offline" 